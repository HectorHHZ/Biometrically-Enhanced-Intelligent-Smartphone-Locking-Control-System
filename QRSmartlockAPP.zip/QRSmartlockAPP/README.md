# QRSmartlockAPP
Android application for managing and unlocking Smartlocks
