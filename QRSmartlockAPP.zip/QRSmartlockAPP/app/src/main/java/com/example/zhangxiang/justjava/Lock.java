package com.example.zhangxiang.justjava;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

import java.util.Objects;

/*
 * Copyright (C) 2017 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * A basic class representing an entity that is a row in a one-column database table.
 *
 * @ Entity - You must annotate the class as an entity and supply a table name if not class name.
 * @ PrimaryKey - You must identify the primary key.
 * @ ColumnInfo - You must supply the column name if it is different from the variable name.
 *
 * See the documentation for the full rich set of annotations.
 * https://developer.android.com/topic/libraries/architecture/room.html
 */

@Entity(tableName = "lock_table")
public class Lock {
//    @PrimaryKey
//    @NonNull
//    private final String lock;
//
//    @ColumnInfo(name = "last_name")
//    private String lastName;
//
//    public Lock(String lock, String lastName) {
//        this.lock = lock;
//        this.lastName = lastName;
//    }
//
//    public String getLock() {
//        return lock;
//    }
////    public void setUid(String uId) {
////        this.uid= uId;
////    }
//
//    public String getLastName() {
//        return lastName;
//    }
////    public void setLastName(String lastName) {
////        this.lastName = lastName;
////    }



    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "lock_")
    private String mLock; // the primary key is the lock's number such as 0001

    //@NonNull
    @ColumnInfo(name = "lock_user_id_")
    private String mLockUserID; // stores the user ID

    //@NonNull
    @ColumnInfo(name = "lock_nickname_")
    private String mLockNickname; // stores the nickname of the lock

    //@NonNull
    @ColumnInfo(name = "lock_start_") // start time
    private String mLockStart;

    //@NonNull
    @ColumnInfo(name = "lock_end_") // end time
    private String mLockEnd;

    //@NonNull
    @ColumnInfo(name = "lock_authorize_") // Whether this lock permits the user to authorize to others
    private String mLockAuthorize;




    public Lock(@NonNull String lock) {
        this.mLock = lock;
    }

    @Ignore
    // Use lock_id as PK and as the identifier of the Lock Entity
    public Lock(@NonNull String lock, String lock_user_id, String lock_nickname, String lock_start_time, String lock_end_time, String lock_authorize) { //, @NonNull String lock_user_id, @NonNull String lock_nickname, @NonNull String lock_start_time, @NonNull String lock_end_time, @NonNull String lock_authorize
        this.mLock = lock;
        this.mLockUserID = lock_user_id;
        this.mLockNickname = lock_nickname;
        this.mLockStart = lock_start_time;
        this.mLockEnd = lock_end_time;
        this.mLockAuthorize = lock_authorize;
    }

    // Setter
    public void setLock(@NonNull String lock) {
        this.mLock = lock;
    }

    public void setLockUserID(String lock_user_id) {
        this.mLockUserID = lock_user_id;
    }

    public void setLockNickname(String lock_nickname) {
        this.mLockNickname = lock_nickname;
    }

    public void setLockStart(String lock_start_time) {
        this.mLockStart = lock_start_time;
    }

    public void setLockEnd(String lock_end_time) {
        this.mLockEnd = lock_end_time;
    }

    public void setLockAuthorize(String lock_authorize) {
        this.mLockAuthorize = Objects.requireNonNull(lock_authorize);
    }

//
//    // Getter
    //@NonNull
    public String getLock() {
        return this.mLock;
    }

    //@NonNull
    public String getLockUserID() {
        return this.mLockUserID;
    }

    //@NonNull
    public String getLockNickname() {
        return this.mLockNickname;
    }

    //@NonNull
    public String getLockStart() {
        return this.mLockStart;
    }

    //@NonNull
    public String getLockEnd() {
        return this.mLockEnd;
    }

    //@NonNull
    public String getLockAuthorize() {
        return this.mLockAuthorize;
    }





}