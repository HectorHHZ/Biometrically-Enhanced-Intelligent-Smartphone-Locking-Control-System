package com.example.zhangxiang.justjava;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;


//import com.example.zhangxiang.justjava.R;

public class TabFragment extends Fragment
{
	private String mTitle = "Default";

	public static final String TITLE = "title";

	//String qrCode = "default"; // public qrcode content

	// For database
	public static final int NEW_LOCK_ACTIVITY_REQUEST_CODE = 1;
	public static final int DELETE_LOCK_ACTIVITY_REQUEST_CODE = 2;

	// For database
	private LockViewModel mLockViewModel;

	//for collecting authorized locks
	private List<String> data_list;

    //private Lock lockToDelete;

	private List<Lock> locks_local;


	/* 下面是关于日期Widget的变量设置 */
	// 声明日期与时间变量
	private int mYear;
	private int mMonth;
	private int mDay;
	private int mHour;
	private int mMinute;

	private int mYear2;
	private int mMonth2;
	private int mDay2;
	private int mHour2;
	private int mMinute2;


	/* 声明对象变量 */
	TextView timeTv;
	TimePicker tp;
	DatePicker dp;

	TextView timeTv2;
	TimePicker tp2;
	DatePicker dp2;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState)
	{
		if (getArguments() != null)
		{
			mTitle = getArguments().getString(TITLE);
		}

// Original code
//		TextView tv = new TextView(getActivity());
//		tv.setTextSize(20);
//		tv.setBackgroundColor(Color.parseColor("#ffffffff"));
//		tv.setText(mTitle);
//		tv.setGravity(Gravity.CENTER);
//      return tv;

		// use getActivity() to let the fragment know relative Activity and thus able to use Activity.findViewById()

		final View view_home = inflater.inflate(R.layout.home, container, false);
		final View view_authorize = inflater.inflate(R.layout.authorize, container, false);

        final View view_history = inflater.inflate(R.layout.history, container, false);
        final View view_extension = inflater.inflate(R.layout.extension, container, false);

        data_list = new ArrayList<String>();
		data_list.add("0001");
//		data_list.add("0002");
//		data_list.add("0003");

		if (mTitle == "home")
		{

			final RecyclerView recyclerView = view_home.findViewById(R.id.recyclerview_home);
			final LockListAdapter adapter = new LockListAdapter(getActivity()); // this
			recyclerView.setAdapter(adapter);
			recyclerView.setLayoutManager(new LinearLayoutManager(getActivity())); //this

			// Get a new or existing ViewModel from the ViewModelProvider.
			mLockViewModel = ViewModelProviders.of(this).get(LockViewModel.class);

			// Add an observer on the LiveData returned by getAlphabetizedWords.
			// The onChanged() method fires when the observed data changes and the activity is
			// in the foreground.
			mLockViewModel.getAllLocks().observe(this, new Observer<List<Lock>>() {
				@Override
				public void onChanged(@Nullable final List<Lock> locks) {
					// Update the cached copy of the words in the adapter.
					adapter.setLocks(locks);
//					final Button open_lock = view_home.findViewById(R.id.open_lock);
//					adapter.setOpenLockButton(open_lock, getActivity(), qrCode);
					//data_list = adapter.getLocks();
					locks_local = locks;
//					data_list.clear();
//					for (int x = 0; x <  locks_local.size(); x++) {
//						data_list.add(locks_local.get(x).getLock());
//					}
					updateSpinner();
				}

			});


//		FloatingActionButton fab = findViewById(R.id.fab);
//		fab.setOnClickListener(new View.OnClickListener() {
//			@Override
//			public void onClick(View view) {
//				Intent intent = new Intent(MainActivity.this, NewLockActivity.class);
//				startActivityForResult(intent, NEW_LOCK_ACTIVITY_REQUEST_CODE);
//			}
//		});

			Button fab_add = view_home.findViewById(R.id.fab_add_home);
			fab_add.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					Intent intent = new Intent(getActivity(), NewLockActivity.class);
					startActivityForResult(intent, NEW_LOCK_ACTIVITY_REQUEST_CODE);
				}
			});

			Button fab_delete = view_home.findViewById(R.id.fab_delete_home);
			fab_delete.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					Intent intent = new Intent(getActivity(), DeleteLockActivity.class);
					startActivityForResult(intent, DELETE_LOCK_ACTIVITY_REQUEST_CODE);
				}
			});

			return view_home;
		}

		else if (mTitle == "authorize")
		{
			// spinner for authorized lock


			ArrayAdapter<String> arr_adapter;
			Spinner spinner = (Spinner) view_authorize.findViewById(R.id.lock_spinner);
			//data_list = new ArrayList<String>();
//			data_list.add("0001"); //在这个list中加入当前数据库里有Y的authorize的锁号
//			data_list.add("0002"); //在这个list中加入当前数据库里有Y的authorize的锁号

			arr_adapter= new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, data_list);
			//设置样式
			arr_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
			//加载适配器
			spinner.setAdapter(arr_adapter);

			final EditText editTextView = view_authorize.findViewById(R.id.edit_authorized_key);

			spinner.setOnItemSelectedListener(new Spinner.OnItemSelectedListener() {//选择item的选择点击监听事件
				public void onItemSelected(AdapterView<?> arg0, View arg1,
										   int arg2, long arg3) {
					// TODO Auto-generated method stub
					// 将所选mySpinner 的值带入myTextView 中

					editTextView.setText(data_list.get(arg2));//文本说明 锁的编号（本来应该放昵称，但这里涉及的数据库关联就更复杂了
					// put all the latest data here
				}

				public void onNothingSelected(AdapterView<?> arg0) {
					// TODO Auto-generated method stub
					editTextView.setText("Nothing");
				}
			});


			// 取得目前日期与时间
			Calendar c = Calendar.getInstance();
			mYear = c.get(Calendar.YEAR);
			mMonth = c.get(Calendar.MONTH);
			mDay = c.get(Calendar.DAY_OF_MONTH);
			mHour = c.get(Calendar.HOUR_OF_DAY);
			mMinute = c.get(Calendar.MINUTE);

			mYear2 = c.get(Calendar.YEAR);
			mMonth2 = c.get(Calendar.MONTH);
			mDay2 = c.get(Calendar.DAY_OF_MONTH);
			mHour2 = c.get(Calendar.HOUR_OF_DAY);
			mMinute2 = c.get(Calendar.MINUTE);

//			super.onCreate(savedInstanceState);
//			setContentView(R.layout.master);

			// 取得TextView对象，并调用updateDisplay()来设置显示的初始日期时间
			timeTv = (TextView) view_authorize.findViewById(R.id.showTimeOut);
			updateDisplay(timeTv);

			timeTv2 = (TextView) view_authorize.findViewById(R.id.showTimeOut2);
			updateDisplay(timeTv2);

			// 取得DatePicker对象，以init()设置初始值与onDateChangeListener()
			dp = (DatePicker) view_authorize.findViewById(R.id.dPicker);
			dp.init(mYear, mMonth, mDay, new DatePicker.OnDateChangedListener() {
				@Override
				public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
					mYear = year;
					mMonth = monthOfYear;
					mDay = dayOfMonth;
					updateDisplay(timeTv); // 调用以改变显示日期
				}
			});

			dp2 = (DatePicker) view_authorize.findViewById(R.id.dPicker2);
			dp2.init(mYear2, mMonth2, mDay2, new DatePicker.OnDateChangedListener() {
				@Override
				public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
					mYear2 = year;
					mMonth2 = monthOfYear;
					mDay2 = dayOfMonth;
					updateDisplay(timeTv2); // 调用以改变显示日期
				}
			});

			// 取得TimePicker对象，并设置为24小时制显示
			tp = (TimePicker)view_authorize.findViewById(R.id.tPicker);
			tp.setIs24HourView(true);

			// setOnTimeChangedListener, 并重写onTimeChanged event
			tp.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
				@Override
				public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
					mHour = hourOfDay;
					mMinute = minute;
					updateDisplay(timeTv); // 调用以改变显示时间
				}
			});

			tp2 = (TimePicker)view_authorize.findViewById(R.id.tPicker2);
			tp2.setIs24HourView(true);

			// setOnTimeChangedListener, 并重写onTimeChanged event
			tp2.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
				@Override
				public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
					mHour2 = hourOfDay;
					mMinute2 = minute;
					updateDisplay(timeTv2); // 调用以改变显示时间
				}
			});

			final Button showEncryptKeyButton = view_authorize.findViewById(R.id.show_encrypted_key_button);
			showEncryptKeyButton.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					// should judge whether qualified
					showEncryptedKey(view_authorize);
				}
			});

			return view_authorize;
		}

		else if (mTitle == "history")
		{
			//tv.setText("Yes it's history!");
            return view_history;
		}

		else if (mTitle == "extension")
		{
			//tv.setText("Yes it's extension!");
            return view_extension;
		}


		View v = new View(getActivity());
		return v;


	}

	@Override
	public void onActivityCreated(Bundle savedInstanceState) {
		super.onActivityCreated(savedInstanceState);
		if (mTitle == "home")
		{
			// Show the device ID
			TextView androidIdView = (TextView) getActivity().findViewById(R.id.show_android_id_1);
			androidIdView.setText("您的设备ID是： " + Settings.Secure.getString(getActivity().getContentResolver(), Settings.Secure.ANDROID_ID));


		}

		else if (mTitle == "authorize")
		{

		}

		else if (mTitle == "history")
		{
			//tv.setText("Yes it's history!");
		}

		else if (mTitle == "extension")
		{
			//tv.setText("Yes it's extension!");
		}

	}

	// For database
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (requestCode == NEW_LOCK_ACTIVITY_REQUEST_CODE && resultCode == getActivity().RESULT_OK) {
			// Do operations to the feedback string EXTRA_REPLY
			String userInput = data.getStringExtra(NewLockActivity.EXTRA_REPLY);
			String[] divideByNickname = userInput.split("TTTnicknameTTT"); //decode the userInput to lockCodeInput and Nickname by User
			String userInputCode = divideByNickname[0];
			String userInputNickname = divideByNickname[1];

			if (userInputCode.length() == 4) { // for master
				Lock lock = new Lock(decryptLockForMaster(userInputCode), "testID", userInputNickname, "190001012330", "299912312330", "Y"); //,"testID", "Home", "201812151030", "201912302330", "Y"); //, "testID", "Home", "201812151030", "201912302330", "Y"
				mLockViewModel.insert(lock);
				Toast.makeText(
						getContext().getApplicationContext(),
						R.string.new_master_lock_add,
						Toast.LENGTH_LONG).show();

			} else if (userInputCode.length() != 4 && userInputCode.startsWith("Z")){ // need more robust detecting method
				// for customer
				String decryptLockForCust = getPermission(userInputCode);
				if (decryptLockForCust.equalsIgnoreCase("Incorrect")) {
					Toast.makeText(
							getContext().getApplicationContext(),
							R.string.empty_invalid,
							Toast.LENGTH_LONG).show();
				} else {
					// If approved, add a new lock with the new lockID
					String[] decryptLockInfo = decryptLockForCust.split("fenge");
					Lock lock = new Lock(decryptLockInfo[0], "testID", userInputNickname, decryptLockInfo[1], decryptLockInfo[2], "N"); //,"testID", "Home", "201812151030", "201912302330", "Y"); //, "testID", "Home", "201812151030", "201912302330", "Y"
					mLockViewModel.insert(lock);
					Toast.makeText(
							getContext().getApplicationContext(),
							R.string.new_customer_lock_add,
							Toast.LENGTH_LONG).show();
				}
			} else {
				Toast.makeText(
						getContext().getApplicationContext(),
						R.string.empty_invalid,
						Toast.LENGTH_LONG).show();
			}

//			Lock lock = new Lock(data.getStringExtra(NewLockActivity.EXTRA_REPLY));
//			mLockViewModel.insert(lock);


		} else if (requestCode == DELETE_LOCK_ACTIVITY_REQUEST_CODE && resultCode == getActivity().RESULT_OK) {

			String userInput = data.getStringExtra(NewLockActivity.EXTRA_REPLY);
            //final Lock lockToDelete;
//			mLockViewModel.getCertainLock(userInput).observe(this, new Observer<Lock>() {
//				@Override
//				public void onChanged(@Nullable final Lock certainLock) {
//					 lockToDelete = certainLock;
//					 String lock_id = lockToDelete.getLock();
//                    Toast.makeText(
//                            getContext().getApplicationContext(),
//                            (lock_id),
//                            Toast.LENGTH_LONG).show();
//
//				}
//			});
            //mLockViewModel.delete(userInput);

			int flag = 0;
			for (int x = 0; x <  locks_local.size(); x++) {

				if (locks_local.get(x).getLock().equalsIgnoreCase(userInput)) {
					mLockViewModel.delete(locks_local.get(x));
					flag = flag + 1;
				}
			}

			if (flag != 0) {
				Toast.makeText(
						getContext().getApplicationContext(),
						("已删除 " + userInput + " 号锁"),
						Toast.LENGTH_LONG).show();
			} else {
				Toast.makeText(
						getContext().getApplicationContext(),
						("没有对应的锁可以删除，请检查输入"),
						Toast.LENGTH_LONG).show();
			}

		} else {
			Toast.makeText(
					getContext().getApplicationContext(),
					R.string.empty_not_saved,
					Toast.LENGTH_LONG).show();
		}
	}

	public String decryptLockForMaster(String userInput){ //robust need to improve
		long decimalResult = Long.parseLong(userInput, 16);
		String stringResult = decimalResult + "";
		stringResult = stringResult.substring(1);
		if (stringResult.length() == 4) {
			return stringResult;

		} else {
			return "1001";//temporary way of showing error
		}

	}

	// For Time & Date picker
	private void updateDisplay(TextView timeTv1or2){
		if (timeTv1or2.equals(timeTv)) {
			timeTv.setText(
					new StringBuilder().append(mYear)//.append("/")
							.append(format(mMonth + 1))//.append("/")
							.append(format(mDay))//.append("  ")
							.append(format(mHour))//.append(":")
							.append(format(mMinute))
			);
		} else if (timeTv1or2.equals(timeTv2)){
			timeTv2.setText(
					new StringBuilder().append(mYear2)//.append("/")
							.append(format(mMonth2 + 1))//.append("/")
							.append(format(mDay2))//.append("  ")
							.append(format(mHour2))//.append(":")
							.append(format(mMinute2))
			);
		}
	}

	private String format(int x){
		String s = "" + x;
		if(s.length() == 1) s = "0" + s;
		return s;
	}

	// 权限管理页面的加密授权过程，包含到最后显示加密后的密钥
	public void showEncryptedKey(View view){
        String str1; //To store customer's id
        String str2; //To store time information
        String str3; //To store authorized key ID
        EditText editText1 = (EditText) view.findViewById(R.id.edit_customer_id);
        //EditText editText2 = (EditText) view.findViewById(R.id.edit_time); //In the future, this should be combined with a time widget instead of pure text input.
        EditText editText3 = (EditText) view.findViewById(R.id.edit_authorized_key);
        str1 = editText1.getText().toString();
        //str2 = editText2.getText().toString();
//		if ( Integer.parseInt(timeTv.getText().toString()) >= Integer.parseInt(timeTv2.getText().toString())) {
//			str2 = "";
//		} else {
//			str2 = timeTv.getText().toString() + timeTv2.getText().toString();
//		}
		str2 = timeTv.getText().toString() + timeTv2.getText().toString();
        str3 = editText3.getText().toString();
        //Can put if conditions here to set limitations
		if (str1.isEmpty() || str2.isEmpty() || str3.isEmpty() || str3.length() != 4) {
			Toast.makeText(view.getContext(), "请输入完整有效的各项信息", Toast.LENGTH_SHORT).show();
		} else {
			displayEncryptedKey(str1, str2, str3, view);
		}


    }

    private void displayEncryptedKey(String customerId, String combinedTime, String authorizedKeyId, View view) { //加密算法应被放置在此！
        TextView testView2 = (TextView) view.findViewById(R.id.show_encrypted_key);
        try {
            long startTime= Long.parseLong(combinedTime.substring(0,12));
            long endTimeWithLockId = Long.parseLong(combinedTime.substring(12)+authorizedKeyId); //要给客人自己主动选择的权利

            long longCustomerId10_1 = Long.parseLong(customerId.substring(0,8), 16);
            long longCustomerId10_2 = Long.parseLong(customerId.substring(8), 16);

            //转化数字完成，运行加密算法并输出结果

            testView2.setText(String.format("%s%s%s%s", toEncrypt(startTime), toEncrypt(endTimeWithLockId), toEncrypt(longCustomerId10_1), toEncrypt(longCustomerId10_2)));

        } catch (NumberFormatException e) {
            e.printStackTrace();
        }

    }

    private String toEncrypt(long rawNum){ //对原数字进行"加密"的一波操作
        long integral = (rawNum * 7) / 10007;
        long remainder = (rawNum * 7) % 10007;
        String strInt = String.valueOf(integral);
        String strRem = String.valueOf(remainder);
        return "Z" + strInt + "Y" + strRem;
    }

    // 下面这个函数是在home页添加新锁的activity中客户输入主人生成的加密密钥后，确认给客户页面添加新锁
    public String getPermission(String userInput){ //应该能对每一把锁都适用的一个函数，update对应的锁id信息
        //此处应改为try/if else语句，在密码不正确的情况下给出提示，而非闪退
        //在此将临时密钥解开并确认授权情况
        //更新客人目前所拥有授权的锁的数据
        //TextView updateCustomer = (TextView) view.findViewById(R.id.update_available_lock);
        //TextView getEncryptedKey = (TextView) view.findViewById(R.id.enter_encrypted_key);
        //String encryptedKey = getEncryptedKey.getText().toString();

        String[] divideByZ = userInput.split("Z");  //divideBy[1]=第一组取整+Y+余数
        String[] divideByY1 = divideByZ[1].split("Y");
        String[] divideByY2 = divideByZ[2].split("Y");
        String[] divideByY3 = divideByZ[3].split("Y");
        String[] divideByY4 = divideByZ[4].split("Y");
        String z1 = divideByY1[0];
        String y1 = divideByY1[1];
        String z2 = divideByY2[0];
        String y2 = divideByY2[1];
        String z3 = divideByY3[0];
        String y3 = divideByY3[1];
        String z4 = divideByY4[0];
        String y4 = divideByY4[1];

        long startTime = (Long.parseLong(z1) * 10007 + Long.parseLong(y1)) / 7;
        String sT = startTime + "";

        long endTimeWithLockId = (Long.parseLong(z2) * 10007 + Long.parseLong(y2)) / 7;
        String eTWL = endTimeWithLockId + "";
        String eT = eTWL.substring(0,12);

        String availableLock = eTWL.substring(12);

        long decCusID1 = (Long.parseLong(z3) * 10007 + Long.parseLong(y3)) / 7;
        long decCusID2 = (Long.parseLong(z4) * 10007 + Long.parseLong(y4)) / 7;
        String decCID1 = decCusID1 + "";
        String decCID2 = decCusID2 + "";
        //String octCustomerId = octCID1 + octCID2;
        //long longOctCustomerId = Long.parseLong(octCustomerId);
        long longDecCustomerId1 = Long.parseLong(decCID1);
        long longDecCustomerId2 = Long.parseLong(decCID2);

        String hexCustomerId1 = Long.toHexString(longDecCustomerId1);
        String hexCustomerId2 = Long.toHexString(longDecCustomerId2);
        String hexCustomerId = hexCustomerId1+hexCustomerId2;

        if (hexCustomerId.equals(Settings.Secure.getString(getActivity().getContentResolver(), Settings.Secure.ANDROID_ID))){
        	// If so, add a new lock by returning something?
            return availableLock + "fenge" + sT + "fenge" +  eT;
        } else {
            // If not, don't add a new lock
			return "Incorrect";
        }

    }


    void updateSpinner() {
		Spinner spinner = getActivity().findViewById(R.id.lock_spinner);
		ArrayAdapter<String> arr_adapter;

		data_list.clear();
		for (int x = 0; x < locks_local.size(); x++) {
			data_list.add(locks_local.get(x).getLock());
		}

		arr_adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, data_list);
		//设置样式
		arr_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		//加载适配器
		spinner.setAdapter(arr_adapter);

	}

}
