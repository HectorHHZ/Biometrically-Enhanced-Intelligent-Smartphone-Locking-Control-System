package com.example.zhangxiang.justjava;

/*
 * Copyright (C) 2017 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class LockListAdapter extends RecyclerView.Adapter<LockListAdapter.LockViewHolder> {

    class LockViewHolder extends RecyclerView.ViewHolder {

        //private final Context context;
        private final TextView lockItemView;
        private final TextView nicknameView;
        private final TextView validTimeView;
        private final Button open_lock;
        private final Button delete_lock;

        private LockViewHolder(final View itemView) {
            super(itemView);
            //context = itemView.getContext();
            lockItemView = itemView.findViewById(R.id.textView);
            nicknameView = itemView.findViewById(R.id.lockTitle);
            validTimeView = itemView.findViewById(R.id.validTime);

            open_lock = itemView.findViewById(R.id.open_lock); // For the button to open the lock
            delete_lock = itemView.findViewById(R.id.delete_lock); // For the button to open the lock
        }
    }

    private final LayoutInflater mInflater;
    private List<Lock> mLocks = Collections.emptyList(); // Cached copy of locks

    LockListAdapter(Context context) {
        mInflater = LayoutInflater.from(context);
    }

    @Override
    public LockViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = mInflater.inflate(R.layout.recyclerview_item, parent, false);
        return new LockViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(LockViewHolder holder, final int position) {
        final Lock current = mLocks.get(position);
        holder.lockItemView.setText(current.getLock());
        holder.nicknameView.setText(current.getLockNickname());

        // show the valid time period
        if (current.getLockStart().startsWith("1900")) {
            holder.validTimeView.setText("永久");
        } else {
            String start_time = current.getLockStart().substring(0,4) + "年" + current.getLockStart().substring(4,6) +
                    "月" + current.getLockStart().substring(6,8) + "日" + current.getLockStart().substring(8,10) + "时" + current.getLockStart().substring(10) + "分";
            String end_time = current.getLockEnd().substring(0,4) + "年" + current.getLockEnd().substring(4,6) +
                    "月" + current.getLockEnd().substring(6,8) + "日" + current.getLockEnd().substring(8,10) + "时" + current.getLockEnd().substring(10) + "分";
            holder.validTimeView.setText(start_time + "\n至\n" + end_time);
        }

        // Added for button
        holder.open_lock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(view.getContext(), "ITEM PRESSED = " + String.valueOf(position), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(view.getContext(), VerifybioShowQR.class);
                // Take the Start & End Time + Lock ID to set as the content of QR code
                String qrCodeForThis = current.getLockStart() + current.getLockEnd() + current.getLock();
                intent.putExtra("qrCodeFromMain", qrCodeForThis); //将公有变量qrCode通过intent的方法传输去第二个activity
                view.getContext().startActivity(intent);
            }
        });
        holder.delete_lock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(view.getContext(), "ITEM PRESSED = " + String.valueOf(position), Toast.LENGTH_SHORT).show();
                // Here we want to delete the lock directly from the database

//                LockDao mLockDao;
//                Application application;
//                LockRoomDatabase db = LockRoomDatabase.getDatabase(getContext());
//                mLockDao = db.lockDao();
//                mLockDao.deleteLock(current);
                //mLocks.remove(position);
            }
        });

    }

    void setLocks(List<Lock> locks) {
        mLocks = locks;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return mLocks.size();
    }

    // new function for returning all the available locks
    public List<String> getLocks() {
        List<String> data_list = new ArrayList<String>();
        for (int x = 0; x < mLocks.size(); x++) {
            data_list.add(mLocks.get(x).getLock());
        }

        return data_list;
    }

}

