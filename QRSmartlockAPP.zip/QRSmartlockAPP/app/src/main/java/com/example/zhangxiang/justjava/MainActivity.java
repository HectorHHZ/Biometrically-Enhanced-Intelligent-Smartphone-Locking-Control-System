package com.example.zhangxiang.justjava;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewConfiguration;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


import android.support.v7.app.AppCompatActivity;

import android.support.v7.widget.Toolbar;
import com.example.zhangxiang.justjava.R;

public class MainActivity extends FragmentActivity implements OnClickListener,
		OnPageChangeListener
{

	private ViewPager mViewPager;
	private List<Fragment> mTabs = new ArrayList<Fragment>();
	private String[] mTitles = new String[]
	{ "home", "authorize", "history",
			"extension" };
	private FragmentPagerAdapter mAdapter;

	private List<com.example.zhangxiang.justjava.ChangeColorIconWithText> mTabIndicators = new ArrayList<com.example.zhangxiang.justjava.ChangeColorIconWithText>();

//	// For database
//	public static final int NEW_LOCK_ACTIVITY_REQUEST_CODE = 1;
//
//	// For database
//	private LockViewModel mLockViewModel;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		setOverflowButtonAlways();
		getActionBar().setDisplayShowHomeEnabled(false);

		initView();
		initDatas();
		mViewPager.setAdapter(mAdapter);
		initEvent();


//		// For database
////		Toolbar toolbar = findViewById(R.id.toolbar);
////		setSupportActionBar(toolbar);
//
//		RecyclerView recyclerView = findViewById(R.id.recyclerview);
//		final LockListAdapter adapter = new LockListAdapter(this);
//		recyclerView.setAdapter(adapter);
//		recyclerView.setLayoutManager(new LinearLayoutManager(this));
//
//		// Get a new or existing ViewModel from the ViewModelProvider.
//		mLockViewModel = ViewModelProviders.of(this).get(LockViewModel.class);
//
//		// Add an observer on the LiveData returned by getAlphabetizedWords.
//		// The onChanged() method fires when the observed data changes and the activity is
//		// in the foreground.
//		mLockViewModel.getAllLocks().observe(this, new Observer<List<Lock>>() {
//			@Override
//			public void onChanged(@Nullable final List<Lock> locks) {
//				// Update the cached copy of the words in the adapter.
//				adapter.setLocks(locks);
//			}
//		});
//
////		FloatingActionButton fab = findViewById(R.id.fab);
////		fab.setOnClickListener(new View.OnClickListener() {
////			@Override
////			public void onClick(View view) {
////				Intent intent = new Intent(MainActivity.this, NewLockActivity.class);
////				startActivityForResult(intent, NEW_LOCK_ACTIVITY_REQUEST_CODE);
////			}
////		});
//
//		Button fab_add = findViewById(R.id.fab_add);
//		fab_add.setOnClickListener(new View.OnClickListener() {
//			@Override
//			public void onClick(View view) {
//				Intent intent = new Intent(MainActivity.this, NewLockActivity.class);
//				startActivityForResult(intent, NEW_LOCK_ACTIVITY_REQUEST_CODE);
//			}
//		});
	}

//	public void onActivityResult(int requestCode, int resultCode, Intent data) {
//		super.onActivityResult(requestCode, resultCode, data);
//
//		if (requestCode == NEW_LOCK_ACTIVITY_REQUEST_CODE && resultCode == RESULT_OK) {
//			Lock lock = new Lock(data.getStringExtra(NewLockActivity.EXTRA_REPLY));
//			mLockViewModel.insert(lock);
//		} else {
//			Toast.makeText(
//					getApplicationContext(),
//					R.string.empty_not_saved,
//					Toast.LENGTH_LONG).show();
//		}
//	}


	/**
	 * 初始化所有事件
	 */
	private void initEvent()
	{

		mViewPager.setOnPageChangeListener(this);

	}

	private void initDatas()
	{
		for (String title : mTitles)
		{
			com.example.zhangxiang.justjava.TabFragment tabFragment = new com.example.zhangxiang.justjava.TabFragment();
			Bundle bundle = new Bundle();
			bundle.putString(com.example.zhangxiang.justjava.TabFragment.TITLE, title);
			tabFragment.setArguments(bundle);
			mTabs.add(tabFragment);
		}

		mAdapter = new FragmentPagerAdapter(getSupportFragmentManager())
		{

			@Override
			public int getCount()
			{
				return mTabs.size();
			}

			@Override
			public Fragment getItem(int position)
			{
				return mTabs.get(position);
			}
		};
	}

	private void initView()
	{
		mViewPager = (ViewPager) findViewById(R.id.id_viewpager);

		com.example.zhangxiang.justjava.ChangeColorIconWithText one = (com.example.zhangxiang.justjava.ChangeColorIconWithText) findViewById(R.id.id_indicator_one);
		mTabIndicators.add(one);
		com.example.zhangxiang.justjava.ChangeColorIconWithText two = (com.example.zhangxiang.justjava.ChangeColorIconWithText) findViewById(R.id.id_indicator_two);
		mTabIndicators.add(two);
		com.example.zhangxiang.justjava.ChangeColorIconWithText three = (com.example.zhangxiang.justjava.ChangeColorIconWithText) findViewById(R.id.id_indicator_three);
		mTabIndicators.add(three);
		com.example.zhangxiang.justjava.ChangeColorIconWithText four = (com.example.zhangxiang.justjava.ChangeColorIconWithText) findViewById(R.id.id_indicator_four);
		mTabIndicators.add(four);

		one.setOnClickListener(this);
		two.setOnClickListener(this);
		three.setOnClickListener(this);
		four.setOnClickListener(this);

		one.setIconAlpha(1.0f);

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	private void setOverflowButtonAlways()
	{
		try
		{
			ViewConfiguration config = ViewConfiguration.get(this);
			Field menuKey = ViewConfiguration.class
					.getDeclaredField("sHasPermanentMenuKey");
			menuKey.setAccessible(true);
			menuKey.setBoolean(config, false);
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	/**
	 * 设置menu显示icon
	 */
	@Override
	public boolean onMenuOpened(int featureId, Menu menu)
	{

		if (featureId == Window.FEATURE_ACTION_BAR && menu != null)
		{
			if (menu.getClass().getSimpleName().equals("MenuBuilder"))
			{
				try
				{
					Method m = menu.getClass().getDeclaredMethod(
							"setOptionalIconsVisible", Boolean.TYPE);
					m.setAccessible(true);
					m.invoke(menu, true);
				} catch (Exception e)
				{
					e.printStackTrace();
				}
			}
		}

		return super.onMenuOpened(featureId, menu);
	}

	@Override
	public void onClick(View v)
	{
		clickTab(v);

	}

	/**
	 * 点击Tab按钮
	 * 
	 * @param v
	 */
	private void clickTab(View v)
	{
		resetOtherTabs();

		switch (v.getId())
		{
		case R.id.id_indicator_one:
			mTabIndicators.get(0).setIconAlpha(1.0f);
			mViewPager.setCurrentItem(0, false);
			break;
		case R.id.id_indicator_two:
			mTabIndicators.get(1).setIconAlpha(1.0f);
			mViewPager.setCurrentItem(1, false);
			break;
		case R.id.id_indicator_three:
			mTabIndicators.get(2).setIconAlpha(1.0f);
			mViewPager.setCurrentItem(2, false);
			break;
		case R.id.id_indicator_four:
			mTabIndicators.get(3).setIconAlpha(1.0f);
			mViewPager.setCurrentItem(3, false);
			break;
		}
	}

	/**
	 * 重置其他的TabIndicator的颜色
	 */
	private void resetOtherTabs()
	{
		for (int i = 0; i < mTabIndicators.size(); i++)
		{
			mTabIndicators.get(i).setIconAlpha(0);
		}
	}

	@Override
	public void onPageScrolled(int position, float positionOffset,
			int positionOffsetPixels)
	{
		// Log.e("TAG", "position = " + position + " ,positionOffset =  "
		// + positionOffset);
		if (positionOffset > 0)
		{
			com.example.zhangxiang.justjava.ChangeColorIconWithText left = mTabIndicators.get(position);
			com.example.zhangxiang.justjava.ChangeColorIconWithText right = mTabIndicators.get(position + 1);
			left.setIconAlpha(1 - positionOffset);
			right.setIconAlpha(positionOffset);
		}

	}

	@Override
	public void onPageSelected(int position)
	{
		// TODO Auto-generated method stub

	}

	@Override
	public void onPageScrollStateChanged(int state)
	{
		// TODO Auto-generated method stub

	}

}
