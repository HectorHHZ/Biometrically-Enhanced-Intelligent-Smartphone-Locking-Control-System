package com.example.zhangxiang.justjava;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


/**
 * Activity for deleting a lock.
 */

public class DeleteLockActivity extends AppCompatActivity {

    public static final String EXTRA_REPLY = "com.example.android.locklistsql.REPLY";

    private EditText mEditLockView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_lock);
        mEditLockView = findViewById(R.id.edit_delete);

        final Button button = findViewById(R.id.button_delete);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent replyIntent = new Intent();
                if (TextUtils.isEmpty(mEditLockView.getText())) {
                    setResult(RESULT_CANCELED, replyIntent);
                } else {
                    String lockCodeInput = mEditLockView.getText().toString();
                    if (lockCodeInput.length() != 4) lockCodeInput = "";
                    replyIntent.putExtra(EXTRA_REPLY, lockCodeInput);
                    setResult(RESULT_OK, replyIntent);
                }
                finish();
            }
        });
    }
}
