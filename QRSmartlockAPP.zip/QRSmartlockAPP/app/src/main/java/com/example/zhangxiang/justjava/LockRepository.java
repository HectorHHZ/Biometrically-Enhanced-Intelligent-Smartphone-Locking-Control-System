package com.example.zhangxiang.justjava;

/*
 * Copyright (C) 2017 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.AsyncTask;

import java.util.List;

/**
 * Abstracted Repository as promoted by the Architecture Guide.
 * https://developer.android.com/topic/libraries/architecture/guide.html
 */

class LockRepository {

    private LockDao mLockDao;
    private LiveData<List<Lock>> mAllLocks;
    //private Lock mLock01;

    // Note that in order to unit test the WordRepository, you have to remove the Application
    // dependency. This adds complexity and much more code, and this sample is not about testing.
    // See the BasicSample in the android-architecture-components repository at
    // https://github.com/googlesamples
    LockRepository(Application application) {
        LockRoomDatabase db = LockRoomDatabase.getDatabase(application);
        mLockDao = db.lockDao();
        mAllLocks = mLockDao.getAllLocks();
    }

    // Room executes all queries on a separate thread.
    // Observed LiveData will notify the observer when the data has changed.
    LiveData<List<Lock>> getAllLocks() {
        return mAllLocks;
    }

//    LiveData<Lock> getLock(String userInput) {
//        return mLockDao.getCertainLock(userInput);
//    }

    // You must call this on a non-UI thread or your app will crash.
    // Like this, Room ensures that you're not doing any long running operations on the main
    // thread, blocking the UI.
    void insert(Lock lock) {
        new insertAsyncTask(mLockDao).execute(lock);
    }

    private static class insertAsyncTask extends AsyncTask<Lock, Void, Void> {

        private LockDao mAsyncTaskDao;

        insertAsyncTask(LockDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final Lock... params) {
            mAsyncTaskDao.insert(params[0]);
            return null;
        }
    }

    // Newly added to delete lock
    void delete(Lock lock) {
        new deleteAsyncTask(mLockDao).execute(lock);
    }

    private static class deleteAsyncTask extends AsyncTask<Lock, Void, Void> {

        private LockDao mAsyncTaskDao;

        deleteAsyncTask(LockDao dao) {
            mAsyncTaskDao = dao;
        }

        @Override
        protected Void doInBackground(final Lock... params) {
            mAsyncTaskDao.deleteLock(params[0]);
            return null;
        }
    }

//    void deleteByName(String inputLock) {
//        //Lock lock = mLockDao.getCertainLock(inputLock);
//        new deleteAsyncTask(mLockDao).execute();
//        //mLockDao.deleteByName(inputLock);
//    }

//    private static class deleteAsyncTask extends AsyncTask<Lock, Void, Void> {
//
//        private LockDao mAsyncTaskDao;
//
//        deleteAsyncTask(LockDao dao) {
//            mAsyncTaskDao = dao;
//        }
//
//        @Override
//        protected Void doInBackground(final Lock... params) {
//            //mAsyncTaskDao.deleteLock(params[0]);
//            mAsyncTaskDao.deleteByName("0001");
//            return null;
//        }
//    }
}