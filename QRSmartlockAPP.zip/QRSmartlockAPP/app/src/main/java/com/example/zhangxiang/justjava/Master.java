//package com.example.zhangxiang.justjava;
//
///**
// * Add your package below. Package name can be found in the project's AndroidManifest.xml file.
// * This is the package name our example uses:
// *
// * package com.example.android.justjava;
// */
//
//import android.os.Bundle;
//import android.provider.Settings;
//import android.support.v7.app.AppCompatActivity;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.Button;
//import android.widget.ImageButton;
//import android.widget.LinearLayout;
//import android.widget.RelativeLayout;
//import android.widget.TextView;
//import android.widget.EditText;
//
//import android.widget.DatePicker;
//import android.widget.TimePicker;
//
//import android.content.Intent;
//import android.content.SharedPreferences;
//import android.util.Log;
//import android.view.View.OnClickListener;
//
//import java.util.ArrayList;
//import java.util.Calendar;
//import java.util.Collection;
//
//import java.security.KeyStore;
//import java.util.LinkedList;
//
//
//
//import javax.crypto.KeyGenerator;
//
//import static java.lang.Integer.parseInt;
//
///**
// * This app displays a prototype for our smart lock.
// */
//
//public class Master extends AppCompatActivity {
//
////    private static final String TAG = MainActivity.class.getSimpleName();
////
////    private static final String DIALOG_FRAGMENT_TAG = "myFragment";
////    private static final String SECRET_MESSAGE = "Very secret message";
////    private static final String KEY_NAME_NOT_INVALIDATED = "key_not_invalidated";
////    static final String DEFAULT_KEY_NAME = "default_key";
////
////    private KeyStore mKeyStore;
////    private KeyGenerator mKeyGenerator;
////    private SharedPreferences mSharedPreferences;
//
//    /* 下面是关于日期Widget的变量设置 */
//    // 声明日期与时间变量
//    private int mYear;
//    private int mMonth;
//    private int mDay;
//    private int mHour;
//    private int mMinute;
//
//    private int mYear2;
//    private int mMonth2;
//    private int mDay2;
//    private int mHour2;
//    private int mMinute2;
//
//
//    /* 声明对象变量 */
//    TextView timeTv;
//    TimePicker tp;
//    DatePicker dp;
//
//    TextView timeTv2;
//    TimePicker tp2;
//    DatePicker dp2;
//
//    Button verifybio_showQR;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        // 取得目前日期与时间
//        Calendar c = Calendar.getInstance();
//        mYear = c.get(Calendar.YEAR);
//        mMonth = c.get(Calendar.MONTH);
//        mDay = c.get(Calendar.DAY_OF_MONTH);
//        mHour = c.get(Calendar.HOUR_OF_DAY);
//        mMinute = c.get(Calendar.MINUTE);
//
//        mYear2 = c.get(Calendar.YEAR);
//        mMonth2 = c.get(Calendar.MONTH);
//        mDay2 = c.get(Calendar.DAY_OF_MONTH);
//        mHour2 = c.get(Calendar.HOUR_OF_DAY);
//        mMinute2 = c.get(Calendar.MINUTE);
//
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.master);
//
//        // 取得TextView对象，并调用updateDisplay()来设置显示的初始日期时间
//        timeTv = (TextView) findViewById(R.id.showTimeOut);
//        updateDisplay(timeTv);
//
//        timeTv2 = (TextView) findViewById(R.id.showTimeOut2);
//        updateDisplay(timeTv2);
//
//        // 取得DatePicker对象，以init()设置初始值与onDateChangeListener()
//        dp = (DatePicker)findViewById(R.id.dPicker);
//        dp.init(mYear, mMonth, mDay, new DatePicker.OnDateChangedListener() {
//            @Override
//            public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
//                mYear = year;
//                mMonth = monthOfYear;
//                mDay = dayOfMonth;
//                updateDisplay(timeTv); // 调用以改变显示日期
//            }
//        });
//
//        dp2 = (DatePicker)findViewById(R.id.dPicker2);
//        dp2.init(mYear2, mMonth2, mDay2, new DatePicker.OnDateChangedListener() {
//            @Override
//            public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
//                mYear2 = year;
//                mMonth2 = monthOfYear;
//                mDay2 = dayOfMonth;
//                updateDisplay(timeTv2); // 调用以改变显示日期
//            }
//        });
//
//        // 取得TimePicker对象，并设置为24小时制显示
//        tp = (TimePicker)findViewById(R.id.tPicker);
//        tp.setIs24HourView(true);
//
//        // setOnTimeChangedListener, 并重写onTimeChanged event
//        tp.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
//            @Override
//            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
//                mHour = hourOfDay;
//                mMinute = minute;
//                updateDisplay(timeTv); // 调用以改变显示时间
//            }
//        });
//
//        tp2 = (TimePicker)findViewById(R.id.tPicker2);
//        tp2.setIs24HourView(true);
//
//        // setOnTimeChangedListener, 并重写onTimeChanged event
//        tp2.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
//            @Override
//            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
//                mHour2 = hourOfDay;
//                mMinute2 = minute;
//                updateDisplay(timeTv2); // 调用以改变显示时间
//            }
//        });
//
//        // 显示当前设备ID
//        displayAndroidId(Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID));
//
//        // 跳转第二个界面按钮关联
//        verifybio_showQR = (Button) findViewById(R.id.unlock_relevant_lock);
//        verifybio_showQR.setOnClickListener(new OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                Intent intent=new Intent();
//                intent.setClass(Master.this, VerifybioShowQR.class);
//                startActivity(intent);
//            }
//        });
//    }
//
//    /*
//     * 分界线
//     */
//
//    private void updateDisplay(TextView timeTv1or2){
//        if (timeTv1or2.equals(timeTv)) {
//            timeTv.setText(
//                    new StringBuilder().append(mYear)//.append("/")
//                            .append(format(mMonth + 1))//.append("/")
//                            .append(format(mDay))//.append("  ")
//                            .append(format(mHour))//.append(":")
//                            .append(format(mMinute))
//            );
//        } else if (timeTv1or2.equals(timeTv2)){
//            timeTv2.setText(
//                    new StringBuilder().append(mYear2)//.append("/")
//                            .append(format(mMonth2 + 1))//.append("/")
//                            .append(format(mDay2))//.append("  ")
//                            .append(format(mHour2))//.append(":")
//                            .append(format(mMinute2))
//            );
//        }
//    }
//
//    private String format(int x){
//        String s = "" + x;
//        if(s.length() == 1) s = "0" + s;
//        return s;
//    }
//
//
//    /*
//     * 分界线
//     */
//
//    String cust_lock_start = "201710010900";
//    String cust_lock_end = "201710082330";
//
//    String lockId1 = "0001"; //锁具的id，与主人手机绑定
//
//    int masterButtonIndex = 0; //计算现在有了主人端生成了多少个对应门锁的button，主人端用
//    int cusButtonIndex = 0; //计算客人端生成了多少个对应门锁的button，客人端用
//    //上下涉嫌重复
//    int master_lock_num = 0; //记录主人绑定的锁总数，主人端用
//    int cust_lock_num = 0; //记录该客人所拥有授权的锁总数，客人端用
//
//    String cust_lock_id = "NULL";
//
//    String qrCode = "default"; //Used to be private static
//    String qrCodeForMaster = "default";
//
//    Collection masterLockSet = new ArrayList(); //为主人的所有锁创建一个集合来记录
//    Collection custLockSet = new ArrayList(); //为客人的所有锁创建一个集合来记录
//
//    private LinearLayout llCusView;
//    private LinearLayout llMasterView;
//
//    //为客人准备的一套增删用Linkedlist，可以捆绑位置和实例
//    LinkedList listIBTNAddCus = new LinkedList<Button>();
//    LinkedList listIBTNDelCus = new LinkedList<Button>();
//
//    LinkedList listIBTNAddMaster = new LinkedList<Button>();
//    LinkedList listIBTNDelMaster = new LinkedList<Button>();
//
//    public String getCommonQrcode() { //Used to be public static
//        return qrCode;
//    }
//
//    class LockClass {
//        private String lockId; //记录该锁的id
//        private String addTime; //记录该锁的添加时刻
//        private String startTime;
//        private String expireTime; //记录该锁的失效时刻
//
//        void setMasterLockInfo(String plockId, String paddTime, String pexpireTime){
//            lockId = plockId;
//            addTime = paddTime;
//            expireTime = pexpireTime;
//        }
//
//        void setCustLockInfo(String plockId, String paddTime, String pstartTime, String pexpireTime){
//            lockId = plockId;
//            addTime = paddTime;
//            startTime = pstartTime;
//            expireTime = pexpireTime;
//        }
//
//
//        String getLockId(){
//            return lockId;
//        }
//
//        String getAddTime(){
//            return addTime;
//        }
//
//        String getStartTime(){
//            return startTime;
//        }
//
//        String getExpireTime(){
//            return expireTime;
//        }
//
//    }
//
//    public void showOwnAndroidId(View view){ //该函数本为按钮点击后显示本机Android ID用，现由于打开APP直接显示Android ID，暂时弃用
//        displayAndroidId(Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID));
////        Context.getSystemService(Context.TELEPHONY_SERVICE)).getDeviceId()
//    }
//
//    private void displayAndroidId(String androidIdString) {
//        TextView androidIdView = (TextView) findViewById(R.id.show_android_id);
//        androidIdView.setText("我的设备ID是： " + androidIdString);
//
//    }
//
//    public void decryptLock(View view){ //robust need to improve
//        String inputKey;
//        EditText editText1 = (EditText) findViewById(R.id.enter_lockId_bind);
//        inputKey = editText1.getText().toString();
//        long decimalResult = Long.parseLong(inputKey, 16);
//        String stringResult = decimalResult + "";
//        stringResult = stringResult.substring(1);
//        if (stringResult.length() == 4) {
//            //判断所添加锁的ID是否与记录锁的ID库中有吻合（还有什么别的核实方法？还是说在加密的时候就设置认证的环节？这样的话可以加入一个特别数字或者字母拿来做认证）
//
//            //接下来应该针对这个锁创建一个类的实例，并对告知主人拥有哪些锁的开锁权限，并且给主人造一个对应的开锁按钮
//            LockClass newLock = new LockClass();
//            newLock.setMasterLockInfo(stringResult, "201801151500", "forever"); //给新的主人锁实例设置三个关键信息
//
//            //LinearLayout mainLinearLayout = (LinearLayout) findViewById(R.id.master);
//            //View btn = createButtonForMaster(modifyQRCodeForMaster(newLock.getLockId()));//在这里根据锁具id，创建新的按钮，且是以View的形式
//            //mainLinearLayout.addView(btn);
//
//            llMasterView = (LinearLayout) this.findViewById(R.id.master); //私有改成公有试试
//            View rlbtn = createButtonForMaster(modifyQRCodeForMaster(newLock.getLockId()));
//            llMasterView.addView(rlbtn); //在这里根据permission中提供的锁具信息，创建新的按钮
//
//            masterLockSet.add(stringResult); //为主人的锁集中添加一个锁
//            //listIBTNAddMaster.add(master_lock_num, btn); //基于LinkedList的实例，同时将location和object绑定存储
//            master_lock_num += 1; //增加主人的锁的总数，注意防止重复添加；必须得在使用createButton函数之前，因为其中要以这个数量设定button的ID
//
//        }
//
//    }
//
//    public void showEncryptedKey(View view){
//        String str1; //To store customer's id
//        String str2; //To store time information
//        String str3; //To store authorized key ID
//        EditText editText1 = (EditText) findViewById(R.id.edit_customer_id);
//        EditText editText2 = (EditText) findViewById(R.id.edit_time); //In the future, this should be combined with a time widget instead of pure text input.
//        EditText editText3 = (EditText) findViewById(R.id.edit_authorized_key);
//        str1 = editText1.getText().toString();
//        //str2 = editText2.getText().toString();
//        str2 = timeTv.getText().toString() + timeTv2.getText().toString();
//        str3 = editText3.getText().toString();
//        //Can put if conditions here to set limitations
//        displayEncryptedKey(str1, str2, str3);
//
//    }
//
//    private void displayEncryptedKey(String customerId, String combinedTime, String authorizedKeyId) { //加密算法应被放置在此！
//        TextView testView2 = (TextView) findViewById(R.id.show_encrypted_key);
//        try {
//            long startTime= Long.parseLong(combinedTime.substring(0,12));
//            long endTimeWithLockId =Long.parseLong(combinedTime.substring(12)+authorizedKeyId); //要给客人自己主动选择的权利
//
//            long longCustomerId10_1 = Long.parseLong(customerId.substring(0,8), 16);
//            long longCustomerId10_2 = Long.parseLong(customerId.substring(8), 16);
//
//            //转化数字完成，运行加密算法并输出结果
//
//            testView2.setText(String.format("%s%s%s%s", toEncrypt(startTime), toEncrypt(endTimeWithLockId), toEncrypt(longCustomerId10_1), toEncrypt(longCustomerId10_2)));
//
//        } catch (NumberFormatException e) {
//            e.printStackTrace();
//        }
//
//    }
//
//    private String toEncrypt(long rawNum){ //对原数字进行"加密"的一波操作
//        long integral = (rawNum * 7) / 10007;
//        long remainder = (rawNum * 7) % 10007;
//        String strInt = String.valueOf(integral);
//        String strRem = String.valueOf(remainder);
//        return "Z" + strInt + "Y" + strRem;
//    }
//
//    public void getPermission(View view){ //应该能对每一把锁都适用的一个函数，update对应的锁id信息
//        //此处应改为try/if else语句，在密码不正确的情况下给出提示，而非闪退
//        //在此将临时密钥解开并确认授权情况
//        //更新客人目前所拥有授权的锁的数据
//        TextView updateCustomer = (TextView) findViewById(R.id.update_available_lock);
//        TextView getEncryptedKey = (TextView) findViewById(R.id.enter_encrypted_key);
//        String encryptedKey = getEncryptedKey.getText().toString();
//        String[] divideByZ = encryptedKey.split("Z");  //divideBy[1]=第一组取整+Y+余数
//        String[] divideByY1 = divideByZ[1].split("Y");
//        String[] divideByY2 = divideByZ[2].split("Y");
//        String[] divideByY3 = divideByZ[3].split("Y");
//        String[] divideByY4 = divideByZ[4].split("Y");
//        String z1 = divideByY1[0];
//        String y1 = divideByY1[1];
//        String z2 = divideByY2[0];
//        String y2 = divideByY2[1];
//        String z3 = divideByY3[0];
//        String y3 = divideByY3[1];
//        String z4 = divideByY4[0];
//        String y4 = divideByY4[1];
//
//        long startTime = (Long.parseLong(z1) * 10007 + Long.parseLong(y1)) / 7;
//        String sT = startTime +"";
//
//        long endTimeWithLockId = (Long.parseLong(z2) * 10007 + Long.parseLong(y2)) / 7;
//        String eTWL = endTimeWithLockId + "";
//        String eT = eTWL.substring(0,12);
//
//        String availableLock = eTWL.substring(12);
//
//        long decCusID1 = (Long.parseLong(z3) * 10007 + Long.parseLong(y3)) / 7;
//        long decCusID2 = (Long.parseLong(z4) * 10007 + Long.parseLong(y4)) / 7;
//        String decCID1 = decCusID1 + "";
//        String decCID2 = decCusID2 + "";
//        //String octCustomerId = octCID1 + octCID2;
//        //long longOctCustomerId = Long.parseLong(octCustomerId);
//        long longDecCustomerId1 = Long.parseLong(decCID1);
//        long longDecCustomerId2 = Long.parseLong(decCID2);
//
//        String hexCustomerId1 = Long.toHexString(longDecCustomerId1);
//        String hexCustomerId2 = Long.toHexString(longDecCustomerId2);
//        String hexCustomerId = hexCustomerId1+hexCustomerId2;
//
//        if (hexCustomerId.equals(Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID))){
//            //if (masterLockSet.contains(availableLock)) { //毫无道理的一个设置……给自己添麻烦，因为这里其实是主客隔离的
//
//            cust_lock_id = availableLock;
//            cust_lock_start = sT;
//            cust_lock_end = eT;
//
//            LockClass newLockCus = new LockClass();
//            newLockCus.setCustLockInfo(availableLock, "test", sT, eT);
//
//            //增加 锁按钮与其删除键 这一整个相对布局
////            LinearLayout mainLinearLayout = (LinearLayout) findViewById(R.id.customer_1);
////            View rlbtn = createButtonForCus(cust_lock_id);
////            mainLinearLayout.addView(rlbtn); //在这里根据permission中提供的锁具信息，创建新的按钮
//            llCusView = (LinearLayout) this.findViewById(R.id.customer_1); //私有改成公有试试
//            View rlbtn = createButtonForCus(cust_lock_id);
//            llCusView.addView(rlbtn); //在这里根据permission中提供的锁具信息，创建新的按钮
//
//            updateCustomer.setText("现在拥有授权的锁数：" + (cust_lock_num+1) + " 把" + //"   编号：" + cust_lock_id +
//                    "\n开始时间： " + cust_lock_start + "\n结束时间： " + cust_lock_end + "\n");
//            qrCode = cust_lock_start + cust_lock_end + cust_lock_id; //Take this 3 important elements for identification with the smart lock when it is decoding the shown QR Code on the screen.
//
//            //为主人的锁集中添加一个锁
//            custLockSet.add(availableLock);
//            //listIBTNAddCus.add(cust_lock_num, btn);
//
//            //if (cust_lock_num == 0)
//            cust_lock_num += 1; //此处应重新调整，不在重复时+1，而仅在添加新锁时加；必须得在使用createButton函数之前，因为其中要以这个数量设定button的ID
//
//            // }
//        } else {
//            updateCustomer.setText("现在拥有授权的锁：" + cust_lock_num + "   编号：" + cust_lock_id);
//        }
//
//        //Below are part of code from generateQRCode()
//    }
//
//
//    public String modifyQRCodeForMaster(String masterLockId) { //该函数主要是为我们解密后的主人锁id悄悄打上一个"M"专属标记
//        masterLockId = masterLockId + "M";
//        return  masterLockId;
//    }
//
//    protected View createButtonForCus(String lockIdSrc){ //获取权限后，创建一个对应锁的id的开锁button，实现页面跳转
//        //创建含有两个按钮的外围控件rlBtn
//        RelativeLayout rlBtn = new RelativeLayout(this);
//
//        //创建锁的对应按钮
//        Button btn = new Button(this); //used to have a 'final'
//        //btn.setId(cusButtonIndex++); //为该按钮设置id，暂时弃用该全局变量
//        btn.setId(cust_lock_num); //为该按钮设置id
//        Log.d("da","id is" + btn.getId());
//
//        btn.setText(lockIdSrc); //使该按钮的文字显示为其锁的编号
//        btn.setOnClickListener(new OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                Intent intent=new Intent();
//                intent.setClass(Master.this, VerifybioShowQR.class);
//                intent.putExtra("qrCodeFromMain", qrCode); //将公有变量qrCode通过intent的方法传输去第二个activity
//                startActivity(intent);
//            }
//        });
//
//        rlBtn.addView(btn);
//        listIBTNAddCus.add(cust_lock_num, btn);
//
//        ////////////////////////////////////////////////////////////////////////////////////////////
//
//        //创建“-”按钮
//        Button btnDelete = new Button(this);
//        btn.setId(cust_lock_num+20000); //为该按钮设置id，
//        btnDelete.setText("-"); //使该按钮的文字显示为"-"号
//        btnDelete.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                deleteCusButton(v);
//            }
//        });
//
//        // 将“-”按钮放到RelativeLayout里
//        rlBtn.addView(btnDelete);
//        listIBTNDelCus.add(cust_lock_num, btnDelete);
//
//        //最后对RelativeLayout整体布局再进行设定
//        RelativeLayout.LayoutParams rlParam = new RelativeLayout.LayoutParams(
//                ViewGroup.LayoutParams.WRAP_CONTENT,
//                ViewGroup.LayoutParams.WRAP_CONTENT);
//
//        rlParam.addRule(RelativeLayout.ALIGN_PARENT_LEFT, RelativeLayout.TRUE);
//        rlParam.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
//
//        btn.setLayoutParams(rlParam);   ////设置按钮的布局属性
//
//        RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(
//                ViewGroup.LayoutParams.WRAP_CONTENT,
//                ViewGroup.LayoutParams.WRAP_CONTENT);
//
//        lp.addRule(RelativeLayout.RIGHT_OF, btn.getId());
//        btnDelete.setLayoutParams(lp);   ////设置按钮的布局属性
//
//        return rlBtn;
//
//        //参考http://blog.csdn.net/suwu150/article/details/51348379
//
//    }
//
//    protected View createButtonForMaster(final String lockIdSrc){ //获取权限后，创建一个对应锁的id的开锁button，实现页面跳转
//        //创建含有两个按钮的外围控件rlBtn
//        RelativeLayout rlBtn = new RelativeLayout(this);
//
//        Button btn = new Button(this);
//        //btn.setId(masterButtonIndex++); //为该按钮设置id，要注意今后要设置不可以重复，应该是要去list里核对；暂时弃用该全局变量
//        btn.setId(master_lock_num);
//        Log.d("da","id is" + btn.getId());
//        btn.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
//        btn.setText(lockIdSrc.substring(0, 4)); //使该按钮的文字显示为其锁的编号，截取前四位，不显示第五位的"M"认证标
//        btn.setOnClickListener(new OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                Intent intent=new Intent();
//                intent.setClass(Master.this, VerifybioShowQR.class);
//                intent.putExtra("qrCodeFromMain", lockIdSrc); //将公有变量qrCode通过intent的方法传输去第二个activity
//                startActivity(intent);
//            }
//        });
//
//        rlBtn.addView(btn);
//        listIBTNAddMaster.add(master_lock_num, btn);
//
//        ////////////////////////////////////////////////////////////////////////////////////////////
//
//        //创建“-”按钮
//        Button btnDelete = new Button(this);
//        btn.setId(master_lock_num+10000); //为该按钮设置id，
//        btnDelete.setText("-"); //使该按钮的文字显示为"-"号
//        btnDelete.setOnClickListener(new View.OnClickListener() {
//
//            @Override
//            public void onClick(View v) {
//                deleteMasterButton(v);
//            }
//        });
//
//        // 将“-”按钮放到RelativeLayout里
//        rlBtn.addView(btnDelete);
//        listIBTNDelMaster.add(master_lock_num, btnDelete);
//
//        //最后对RelativeLayout整体布局再进行设定
//        RelativeLayout.LayoutParams rlParam = new RelativeLayout.LayoutParams(
//                ViewGroup.LayoutParams.WRAP_CONTENT,
//                ViewGroup.LayoutParams.WRAP_CONTENT);
//
//        rlParam.addRule(RelativeLayout.ALIGN_PARENT_LEFT, RelativeLayout.TRUE);
//        rlParam.addRule(RelativeLayout.ALIGN_PARENT_TOP, RelativeLayout.TRUE);
//
//        btn.setLayoutParams(rlParam);   ////设置按钮的布局属性
//
//        RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(
//                ViewGroup.LayoutParams.WRAP_CONTENT,
//                ViewGroup.LayoutParams.WRAP_CONTENT);
//
//        lp.addRule(RelativeLayout.RIGHT_OF, btn.getId());
//        btnDelete.setLayoutParams(lp);   ////设置按钮的布局属性
//
//        return rlBtn;
//
//    }
//
//    protected void deleteCusButton (View v) {
//        if (v == null) {
//            return;
//        }
//
//        // 判断第几个“-”按钮触发了事件
//        int iIndex = -1;
//        for (int i = 0; i < listIBTNDelCus.size(); i++) {
//            if (listIBTNDelCus.get(i) == v) {
//                iIndex = i;
//                break;
//            }
//        }
//        if (iIndex >= 0) {
//            listIBTNAddCus.remove(iIndex);
//            listIBTNDelCus.remove(iIndex);
//            cust_lock_num = cust_lock_num - 1;
//
//            // 从外围llContentView容器里删除第iIndex控件
//            llCusView.removeViewAt(iIndex+5);
//
//            TextView updateCustomer = (TextView) findViewById(R.id.update_available_lock);
//            updateCustomer.setText("现在拥有授权的锁数：" + cust_lock_num + " 把" );
//
//        }
//
//
//        return;
//    }
//
//    protected void deleteMasterButton (View v) {
//        if (v == null) {
//            return;
//        }
//
//        // 判断第几个“-”按钮触发了事件
//        int iIndex = -1;
//        for (int i = 0; i < listIBTNDelMaster.size(); i++) {
//            if (listIBTNDelMaster.get(i) == v) {
//                iIndex = i;
//                break;
//            }
//        }
//        if (iIndex >= 0) {
//            listIBTNAddMaster.remove(iIndex);
//            listIBTNDelMaster.remove(iIndex);
//            master_lock_num = master_lock_num - 1;
//
//            // 从外围llContentView容器里删除第iIndex控件
//            llMasterView.removeViewAt(iIndex + 6);
//        }
//    }
//}