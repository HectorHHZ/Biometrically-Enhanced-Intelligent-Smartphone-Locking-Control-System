package com.example.zhangxiang.justjava;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;

import java.util.List;


/*
 * Copyright (C) 2017 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


/**
 * The Room Magic is in this file, where you map a Java method call to an SQL query.
 *
 * When you are using complex data types, such as Date, you have to also supply type converters.
 * To keep this example basic, no types that require type converters are used.
 * See the documentation at
 * https://developer.android.com/topic/libraries/architecture/room.html#type-converters
 */

@Dao
public interface LockDao {

    // LiveData is a data holder class that can be observed within a given lifecycle.
    // Always holds/caches latest version of data. Notifies its active observers when the
    // data has changed. Since we are getting all the contents of the database,
    // we are notified whenever any of the database contents have changed.
    @Query("SELECT * from lock_table")
    LiveData<List<Lock>> getAllLocks();

    // We do not need a conflict strategy, because the word is our primary key, and you cannot
    // add two items with the same primary key to the database. If the table has more than one
    // column, you can use @Insert(onConflict = OnConflictStrategy.REPLACE) to update a row.

    @Insert
    //@Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(Lock lock);

    @Query("DELETE FROM lock_table")
    void deleteAll();

    @Delete
    void deleteLock(Lock lock);

//    @Query("SELECT * from lock_table WHERE lock_ = 0001 ")
//    Lock getTheLock01();
//    @Query("SELECT * FROM lock_table WHERE lock_ =:input_lock_id")
//    LiveData<Lock> getCertainLock(String input_lock_id);

    @Query("SELECT * FROM lock_table WHERE lock_ =:input_lock_id")
    Lock getCertainLock(String input_lock_id);

    //根据名字删除
    @Query("DELETE FROM lock_table where lock_=:inputLock")
    void deleteByName(String inputLock);

}