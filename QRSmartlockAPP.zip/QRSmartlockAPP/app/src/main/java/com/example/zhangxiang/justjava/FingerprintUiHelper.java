/*
 * Copyright (C) 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License
 */

package com.example.zhangxiang.justjava;

import android.graphics.Bitmap;
import android.hardware.fingerprint.FingerprintManager;
import android.os.CancellationSignal;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

/**
 * Small helper class to manage text/icon around fingerprint authentication UI.
 */
public class FingerprintUiHelper extends FingerprintManager.AuthenticationCallback {

    private static final long ERROR_TIMEOUT_MILLIS = 1600;
    private static final long SUCCESS_DELAY_MILLIS = 30000; //originally 1300, 30秒后窗口会消失

    private final FingerprintManager mFingerprintManager;
    private final ImageView mIcon;
    private final TextView mErrorTextView;
    private final ImageView mQrcode; //newly added image view for displaying the QR code
    private final Button mRefreshQrcode; //newly added image view for refreshing the QR code
    private final Callback mCallback;
    private CancellationSignal mCancellationSignal;

    private boolean mSelfCancelled;

    private String mStoreOldQrCode; //存储最早的二维码信息，包含起止时间+锁的id
    private String mStoreNewQrCode; //存储加入了当前时间的更新后的二维码信息

    public Bitmap generateBitmap(String content, int width, int height) {
        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        Map<EncodeHintType, String> hints = new HashMap<>();
        hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
        try {
            BitMatrix encode = qrCodeWriter.encode(content, BarcodeFormat.QR_CODE, width, height, hints);
            int[] pixels = new int[width * height];
            for (int i = 0; i < height; i++) {
                for (int j = 0; j < width; j++) {
                    if (encode.get(j, i)) {
                        pixels[i * width + j] = 0x00000000;
                    } else {
                        pixels[i * width + j] = 0xffffffff;
                    }
                }
            }
            return Bitmap.createBitmap(pixels, 0, width, width, height, Bitmap.Config.RGB_565);
        } catch (WriterException e) {
            e.printStackTrace();
        }
        return null;
    }

    private String toEncrypt(long rawNum){ //对原数字进行"加密"的一波操作
        long integral = (rawNum * 7) / 10007;
        long remainder = (rawNum * 7) % 10007;
        String strInt = String.valueOf(integral);
        String strRem = String.valueOf(remainder);
        return "Z" + strInt + "Y" + strRem;
    }

    /**
     * Constructor for {@link FingerprintUiHelper}.
     */
    FingerprintUiHelper(FingerprintManager fingerprintManager,
                        ImageView icon, TextView errorTextView, ImageView qrCodeDisplay, Button refreshQrCode, String storeQrCode, Callback callback) { //The last 3rd and last 2nd are created by ZHANGXIANG.
        mFingerprintManager = fingerprintManager;
        mIcon = icon;
        mErrorTextView = errorTextView;
        mQrcode = qrCodeDisplay;
        mRefreshQrcode = refreshQrCode;
        mStoreOldQrCode = storeQrCode;
        mCallback = callback;
    }

    public boolean isFingerprintAuthAvailable() {
        // The line below prevents the false positive inspection from Android Studio
        // noinspection ResourceType
        return mFingerprintManager.isHardwareDetected()
                && mFingerprintManager.hasEnrolledFingerprints();
    }

    public void startListening(FingerprintManager.CryptoObject cryptoObject) {
        if (!isFingerprintAuthAvailable()) {
            return;
        }
        mCancellationSignal = new CancellationSignal();
        mSelfCancelled = false;
        // The line below prevents the false positive inspection from Android Studio
        // noinspection ResourceType
        mFingerprintManager
                .authenticate(cryptoObject, mCancellationSignal, 0 /* flags */, this, null);
        mIcon.setImageResource(R.drawable.ic_fp_40px);
    }

    public void stopListening() {
        if (mCancellationSignal != null) {
            mSelfCancelled = true;
            mCancellationSignal.cancel();
            mCancellationSignal = null;
        }
    }

    @Override
    public void onAuthenticationError(int errMsgId, CharSequence errString) {
        if (!mSelfCancelled) {
            showError(errString);
            mIcon.postDelayed(new Runnable() {
                @Override
                public void run() {
                    mCallback.onError();
                }
            }, ERROR_TIMEOUT_MILLIS);
        }
    }

    @Override
    public void onAuthenticationHelp(int helpMsgId, CharSequence helpString) {
        showError(helpString);
    }

    @Override
    public void onAuthenticationFailed() {
        showError(mIcon.getResources().getString(
                R.string.fingerprint_not_recognized));
    }

    @Override
    public void onAuthenticationSucceeded(FingerprintManager.AuthenticationResult result) {
        mErrorTextView.removeCallbacks(mResetErrorTextRunnable);
        mIcon.setImageResource(R.drawable.ic_fingerprint_success);
        mErrorTextView.setTextColor(
                mErrorTextView.getResources().getColor(R.color.success_color, null));
        mErrorTextView.setText(
                mErrorTextView.getResources().getString(R.string.fingerprint_success)); //originally only fingerprint_success
        mRefreshQrcode.findViewById(R.id.refresh_QRcode); //将该按钮实例与button的id绑定
        mRefreshQrcode.setOnClickListener(new Button.OnClickListener(){ //设置监听按钮并联动函数以刷新实时二维码
            public void onClick(View v){
                refresh_QRcode_display();
            }
        });

        //Below is a big block for completing the data from qrCode/qrCode2/mStoreQrCode, which was just the id of the lock, start time, and end time.
        Calendar calendar = Calendar.getInstance();

        if (mStoreOldQrCode.length() != 28){
            try {
                String year = calendar.get(Calendar.YEAR) + "";
                String month = (calendar.get(Calendar.MONTH) + 1) + "";
                if (month.length() < 2) month = "0" + month;
                String date = calendar.get(Calendar.DATE) + "";
                String hour = calendar.get(Calendar.HOUR_OF_DAY) + "";
                String minute = calendar.get(Calendar.MINUTE) + "";
                String second = calendar.get(Calendar.SECOND) + "";
                long yearMonthDate = Long.parseLong(year + month + date);
                long hourMinuteSecond = Long.parseLong(hour + minute + second);

                //转化数字完成，运行加密算法并输出结果

                String currentTimeEncrypted = toEncrypt(yearMonthDate) + toEncrypt(hourMinuteSecond);
                mStoreNewQrCode = (mStoreOldQrCode + currentTimeEncrypted); //给主人的二维码做修改，加入当时时间的信息以便锁进行核实，防止别有用心之人乱用主人旧的二维码

            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        else {
            try {
                long startTime = Long.parseLong(mStoreOldQrCode.substring(0, 12)); //Not robust enough here. Need to improve. This is start time.
                long endTimeWithLockId = Long.parseLong(mStoreOldQrCode.substring(12)); //End time + lockId.

                //以下对"当前时间"进行分割处理
                String year = calendar.get(Calendar.YEAR) + "";
                String month = (calendar.get(Calendar.MONTH) + 1) + "";
                if (month.length() < 2) month = "0" + month;
                String date = calendar.get(Calendar.DATE) + "";
                String hour = calendar.get(Calendar.HOUR_OF_DAY) + "";
                String minute = calendar.get(Calendar.MINUTE) + "";
                String second = calendar.get(Calendar.SECOND) + "";
                long yearMonthDate = Long.parseLong(year + month + date);
                long hourMinuteSecond = Long.parseLong(hour + minute + second);

                //转化数字完成，运行加密算法并输出结果

                String currentTimeEncrypted = toEncrypt(yearMonthDate) + toEncrypt(hourMinuteSecond); //将当前时间分两组加密
                String qrCodeEncrypted = toEncrypt(startTime) + toEncrypt(endTimeWithLockId) + currentTimeEncrypted; //加密二维码内容=加密后的开始时间+加密后的结束时间与锁编号+加密后的当前时间
                //mStoreNewQrCode = qrCodeEncrypted + "\n" + ("授权： " + mStoreOldQrCode.substring(24) + "\n开始时间： " + mStoreOldQrCode.substring(0,12) + "\n结束时间： "
                //        + mStoreOldQrCode.substring(12,24) + "\n开锁指令通过！" + "\n" + "当前时间为：" + calendar.getTime());
                mStoreNewQrCode = qrCodeEncrypted; //仅留下加密后的信息

            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }

        Bitmap qrBitmap = generateBitmap(mStoreNewQrCode, 256, 256); //These two lines realize displaying our QR code generated from the String qrcode
        mQrcode.setImageBitmap(qrBitmap);

        mIcon.postDelayed(new Runnable() {
            @Override
            public void run() {
                mCallback.onAuthenticated();
            }
        }, SUCCESS_DELAY_MILLIS);
    }

    public void refresh_QRcode_display() { //为刷新二维码而服务的函数
        Calendar calendar = Calendar.getInstance();

        if (mStoreOldQrCode.length() != 28) {
            try {
                String year = calendar.get(Calendar.YEAR) + "";
                String month = (calendar.get(Calendar.MONTH) + 1) + "";
                if (month.length() < 2) month = "0" + month;
                String date = calendar.get(Calendar.DATE) + "";
                String hour = calendar.get(Calendar.HOUR_OF_DAY) + "";
                String minute = calendar.get(Calendar.MINUTE) + "";
                String second = calendar.get(Calendar.SECOND) + "";
                long yearMonthDate = Long.parseLong(year + month + date);
                long hourMinuteSecond = Long.parseLong(hour + minute + second);

                //转化数字完成，运行加密算法并输出结果

                String currentTimeEncrypted = toEncrypt(yearMonthDate) + toEncrypt(hourMinuteSecond);
                mStoreNewQrCode = (mStoreOldQrCode + currentTimeEncrypted); //给主人的二维码做修改，加入当时时间的信息以便锁进行核实，防止别有用心之人乱用主人旧的二维码

            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        } else {
            try {
                long startTime = Long.parseLong(mStoreOldQrCode.substring(0, 12)); //Not robust enough here. Need to improve. This is start time.
                long endTimeWithLockId = Long.parseLong(mStoreOldQrCode.substring(12)); //End time + lockId.

                String year = calendar.get(Calendar.YEAR) + "";
                String month = (calendar.get(Calendar.MONTH) + 1) + "";
                if (month.length() < 2) month = "0" + month;
                String date = calendar.get(Calendar.DATE) + "";
                String hour = calendar.get(Calendar.HOUR_OF_DAY) + "";
                String minute = calendar.get(Calendar.MINUTE) + "";
                String second = calendar.get(Calendar.SECOND) + "";
                long yearMonthDate = Long.parseLong(year + month + date);
                long hourMinuteSecond = Long.parseLong(hour + minute + second);

                //转化数字完成，运行加密算法并输出结果

                String currentTimeEncrypted = toEncrypt(yearMonthDate) + toEncrypt(hourMinuteSecond);
                String qrCodeEncrypted = toEncrypt(startTime) + toEncrypt(endTimeWithLockId) + currentTimeEncrypted;
                mStoreNewQrCode = qrCodeEncrypted; // + "\n" + ("授权： " + mStoreOldQrCode.substring(24) + "\n开始时间： " + mStoreOldQrCode.substring(0,12) + "\n结束时间： "
                //+ mStoreOldQrCode.substring(12,24) + "\n开锁指令通过！" + "\n" + "当前时间为：" + calendar.getTime());

            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
        Bitmap qrBitmap = generateBitmap(mStoreNewQrCode, 256, 256); //These two lines realize displaying our QR code generated from the String qrcode
        mQrcode.setImageBitmap(qrBitmap);
    }


    private void showError(CharSequence error) {
        mIcon.setImageResource(R.drawable.ic_fingerprint_error);
        mErrorTextView.setText(error);
        mErrorTextView.setTextColor(
                mErrorTextView.getResources().getColor(R.color.warning_color, null));
        mErrorTextView.removeCallbacks(mResetErrorTextRunnable);
        mErrorTextView.postDelayed(mResetErrorTextRunnable, ERROR_TIMEOUT_MILLIS);
    }

    private Runnable mResetErrorTextRunnable = new Runnable() {
        @Override
        public void run() {
            mErrorTextView.setTextColor(
                    mErrorTextView.getResources().getColor(R.color.hint_color, null));
            mErrorTextView.setText(
                    mErrorTextView.getResources().getString(R.string.fingerprint_hint));
            mIcon.setImageResource(R.drawable.ic_fp_40px);
        }
    };

    public interface Callback {

        void onAuthenticated();

        void onError();
    }
}
